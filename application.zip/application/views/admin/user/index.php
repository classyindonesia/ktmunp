<?php
$this->load->view('admin/user/mst_user_all');
?>