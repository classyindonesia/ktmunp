<table>
    
    <tr>
        <td>Password Lama</td>
        <td> : </td>
        <td> <?php echo form_password('pass_lama', '', 'id="pass_lama"');?></td>
    </tr>    
    
    <tr>
        <td>Password Baru</td>
        <td> : </td>
        <td> <?php echo form_password('pass1', '', 'id="pass1"');?></td>
    </tr>

    
    <tr>
        <td>Re-Enter Password </td>
        <td> : </td>
        <td> <?php echo form_password('pass2', '', 'id="pass2"');?></td>
    </tr>
</table>