<?php
$this->load->view('admin/mahasiswa/tab_menu');
?>




<?php
$this->load->view('admin/mahasiswa/batch/add_batch');
echo '<div id="list_batch">';
$this->load->view('admin/mahasiswa/batch/list_batch');

?>
</div>