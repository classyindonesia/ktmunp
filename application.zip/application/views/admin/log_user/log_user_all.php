<?php $this->load->view('admin/log_user/search');?>

<h4>log list</h4>
<hr>



<div id="konten_pencarian">
<?php $this->load->view("admin/log_user/log_list");?>
 </div>