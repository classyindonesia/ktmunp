<?php
if(!is_writable('./includes/img/foto_mahasiswa')){
    echo '<span style="color: red"><i class="icon-exclamation-sign"></i> error permission folder /includes/img/foto_mahasiswa/ </span>';
}

?>