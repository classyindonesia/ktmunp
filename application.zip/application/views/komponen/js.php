<script type="text/javascript" src="<?php echo base_url();?>includes/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/jquery.swfobject.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/bootstrap-tooltip.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/bootstrap-modal.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/bootstrap-dropdown.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/bootstrap-popover.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/ajaxfileupload.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>includes/js/jquery.print.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>includes/js/jquery.ba-replacetext.js"></script>
<!--
jquery replace text
source : http://benalman.com/code/projects/jquery-replacetext/examples/replacetext/
-->

<script type="text/javascript" src="<?php echo base_url();?>includes/js/jquery.colorPicker.min.js"></script>