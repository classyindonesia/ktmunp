            <link href="<?php echo base_url();?>includes/css/bootstrap.css" rel="stylesheet">
            <link href="<?php echo base_url();?>includes/css/colorPicker.css" rel="stylesheet">
             <link href="<?php echo base_url();?>includes/css/datepicker.css" rel="stylesheet">