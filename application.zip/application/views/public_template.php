<!DOCTYPE html>
<html lang="en">

    <head>
        <title>Login page</title>

      
     <?php $this->load->view('komponen/css');?>
     <?php $this->load->view('komponen/js');?>

        
    </head>

    <body>
        
        
        
        <div class="container">
            
 <div style="border: 1px solid #ccc; margin-top : 6em;  box-shadow: 3px 5px 5px #aaa;" class="span10 well">
<!--Body content-->
        




<?php
$this->load->view('komponen/public_nav');
$this->load->view($main);
?>
    
        
    </div>  
</div>    
    
    
    
    
    
    
    
    
    
    
</body>
</html>